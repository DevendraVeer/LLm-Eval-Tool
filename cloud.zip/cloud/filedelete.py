from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import os

# AES Settings
KEY = os.urandom(32)  # 256-bit key
IV = os.urandom(16)   # 128-bit IV for CBC mode

def encrypt_file(filename):
    # Read the original file data
    with open(filename, "rb") as f:
        plaintext = f.read()

    # Padding (because AES needs blocks of exact size)
    padding_length = 16 - (len(plaintext) % 16)
    plaintext += bytes([padding_length]) * padding_length

    # Encrypt the data
    cipher = Cipher(algorithms.AES(KEY), modes.CBC(IV), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(plaintext) + encryptor.finalize()

    # Save the encrypted file
    encrypted_filename = filename + ".encrypted"
    with open(encrypted_filename, "wb") as f:
        f.write(IV + ciphertext)  # Saving IV + Encrypted content

    print(f"File encrypted and saved as: {encrypted_filename}")

    return encrypted_filename

def securely_delete_file(filename):
    # Overwrite file with random data
    if os.path.exists(filename):
        filesize = os.path.getsize(filename)
        with open(filename, "wb") as f:
            f.write(os.urandom(filesize))
        os.remove(filename)
        print(f"Original file '{filename}' securely deleted.")
    else:
        print(f"File '{filename}' does not exist!")

# --- MAIN CODE ---

filename = input("Enter the path of the file to encrypt and securely delete: ").strip()

if os.path.exists(filename):
    encrypted_file = encrypt_file(filename)
    securely_delete_file(filename)
else:
    print("File does not exist. Please check the path.")
