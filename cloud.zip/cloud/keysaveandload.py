import os

def generate_and_save_key(index):
    key = os.urandom(32)  # 256-bit AES key
    filename = f"aes_key_{index}.bin"
    with open(filename, "wb") as file:
        file.write(key)
    print(f"New AES key generated and saved to {filename}.")

def load_key(index):
    filename = f"aes_key_{index}.bin"
    if os.path.exists(filename):
        with open(filename, "rb") as file:
            key = file.read()
        print(f"AES key loaded from {filename}.")
        return key
    else:
        print(f"No file named {filename} found.")
        return None

# --- MAIN CODE ---

choice = input("Do you want to (G)enerate and save a key or (L)oad a key? [G/L]: ").strip().upper()

if choice == "G":
    index = input("Enter a number for the key file (e.g., 1, 2, 3): ").strip()
    generate_and_save_key(index)
elif choice == "L":
    index = input("Enter the number of the key file you want to load (e.g., 1, 2, 3): ").strip()
    key = load_key(index)
    if key:
        print(f"Loaded AES Key: {key.hex()}")
else:
    print("Invalid option selected. Please choose 'G' or 'L'.")
