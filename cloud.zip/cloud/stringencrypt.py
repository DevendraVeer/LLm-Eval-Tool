from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Protocol.KDF import PBKDF2
import base64

def derive_key(password, salt):
    return PBKDF2(password, salt, dkLen=32, count=390000)

def encrypt_message(message, password):
    salt = get_random_bytes(16)
    key = derive_key(password.encode(), salt)
    iv = get_random_bytes(16)

    cipher = AES.new(key, AES.MODE_CBC, iv)

    # Pad message
    padding_length = 16 - len(message.encode()) % 16
    padded_message = message.encode() + bytes([padding_length] * padding_length)

    encrypted = cipher.encrypt(padded_message)

    # Return all together encoded
    encrypted_blob = base64.b64encode(salt + iv + encrypted).decode()
    return encrypted_blob

def decrypt_message(encrypted_blob, password):
    decoded_data = base64.b64decode(encrypted_blob.encode())
    salt = decoded_data[:16]
    iv = decoded_data[16:32]
    encrypted_message = decoded_data[32:]

    key = derive_key(password.encode(), salt)
    cipher = AES.new(key, AES.MODE_CBC, iv)

    decrypted_padded = cipher.decrypt(encrypted_message)
    padding_length = decrypted_padded[-1]
    decrypted = decrypted_padded[:-padding_length]

    return decrypted.decode()

# Example usage
if __name__ == "__main__":
    print("1. Encrypt a Message")
    print("2. Decrypt a Message")
    choice = int(input("Choose an option: "))

    if choice == 1:
        message = input("Enter the message to encrypt: ")
        password = input("Enter a password: ")
        encrypted = encrypt_message(message, password)
        print(f"\n🔒 Encrypted Message:\n{encrypted}")
    
    elif choice == 2:
        encrypted_blob = input("Paste the encrypted message: ")
        password = input("Enter the password to decrypt: ")
        try:
            decrypted = decrypt_message(encrypted_blob, password)
            print(f"\n🔓 Decrypted Message:\n{decrypted}")
        except Exception as e:
            print(f"❌ Decryption failed: {str(e)}")
    else:
        print("Invalid choice")
